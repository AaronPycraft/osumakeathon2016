#define PERF_START     ((void) 0)
#define PERF_STOP(msg) ((void) 0)
